# 雪国：一个由 AI 生成的视觉小说

[English](README.md)

## License

本项目所有文本来自川端康成的《雪国》，仅作为演示使用。

美术资源（立绘、背景）生成自 [NovelAI](https://novelai.net)。
BGM 生成自 [AIVA](https://aiva.ai)。
配音生成自 [MoeGoe](https://github.com/CjangCjengh/MoeGoe)。

Yukigoku 项目使用 The Unlicense 配布。