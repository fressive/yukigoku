# Tags of NovelAI generated images

## Main-Visual


## Background 

## Characters

### Youko

normal, `1843394122`, `step=50`
```
masterpiece, best quality, masterpiece,best quality,official art,extremely detailed CG unity 8k wallpaper, game_cg, simple_background, transparent_background, girl, long hair, japanese_clothes, white hair, full body
```

# Tags of Voices

### Youko 

defualt id `4810`

"まあ。いけませんわ" - id `3982`